En esta carpeta de Google Drive estarán los archihvos y documentos del proyecto, ahí está el proyecto para descargar como zip con los paquetes ya instalados.

https://docs.google.com/document/d/1VCK9asKw-LCIM-Tz0gArzFn2N6tfruvcHK0aqA8L9mQ/edit?usp=sharing
