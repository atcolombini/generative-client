'use strict';

const KnownDevices = 
[
    "95237323834351B03240",
    "9593132393135181E170"
];

module.exports = KnownDevices;
